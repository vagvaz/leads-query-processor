/*
_______________________
Apatar Open Source Data Integration
Copyright (C) 2005-2007, Apatar, Inc.
info@apatar.com
195 Meadow St., 2nd Floor
Chicopee, MA 01013

��� This program is free software; you can redistribute it and/or modify
��� it under the terms of the GNU General Public License as published by
��� the Free Software Foundation; either version 2 of the License, or
��� (at your option) any later version.

��� This program is distributed in the hope that it will be useful,
��� but WITHOUT ANY WARRANTY; without even the implied warranty of
��� MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.� See the
��� GNU General Public License for more details.

��� You should have received a copy of the GNU General Public License along
��� with this program; if not, write to the Free Software Foundation, Inc.,
��� 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
________________________

 */

package com.apatar.output;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.Transferable;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JDialog;

import org.jdom.Element;

import com.apatar.core.AbstractApatarActions;
import com.apatar.core.AbstractNonJdbcDataBaseNode;
import com.apatar.core.ApplicationData;
import com.apatar.core.DBTypeRecord;
import com.apatar.core.DataBaseInfo;
import com.apatar.core.DataBaseTools;
import com.apatar.core.DataProcessingInfo;
import com.apatar.core.ERecordType;
import com.apatar.core.JdbcObject;
import com.apatar.core.KeyInsensitiveMap;
import com.apatar.core.RDBTable;
import com.apatar.core.Record;
import com.apatar.core.SchemaTable;
import com.apatar.core.TableInfo;
import com.apatar.output.ui.JDBFileConnectionPanel;
import com.apatar.output.ui.OutputConnectionDescriptor;
import com.apatar.read.READTable;
import com.apatar.read.READTableList;
import com.apatar.read.READUtils;
import com.apatar.ui.wizard.DBConnectionDescriptor;
import com.apatar.ui.wizard.RecordSourceDescriptor;
import com.apatar.ui.wizard.TableModeDescriptor;
import com.apatar.ui.wizard.Wizard;
import com.apatar.ui.wizard.WizardPanelDescriptor;

public class OutputNode extends AbstractNonJdbcDataBaseNode {

	//FileConnectionInfo fci = null;

	static DataBaseInfo dbi = new DataBaseInfo("", "", "", "", true, true,
			false, false, false);

	/*
	public FileConnectionInfo getConnectionInfo() {
		return fci;
	}*/
	

	
	
	static {
		List<DBTypeRecord> rcList = dbi.getAvailableTypes();
		rcList.add(new DBTypeRecord(ERecordType.LongText, "LONGVARCHAR", 0,
				255, false, false));
	}

	public OutputNode() {
		super();
		title = "Output";
		//fci = new FileConnectionInfo(this);
		
		outputConnectionList.clear();
	}



	@Override
	public void createDatabaseParam(Wizard wizard) {
/*
		java.awt.datatransfer.StringSelection stringSelection = new java.awt.datatransfer.StringSelection(
				"ura clipbord rabotaet");

		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		ClipboardOwner owner = new ClipboardOwner() {
			public void lostOwnership(Clipboard clipboard, Transferable contents) {
			}
		};
		clipboard.setContents(stringSelection, owner);

		wizard.getDialog().setTitle(title + " Property");

		WizardPanelDescriptor descriptor1 = new OutputConnectionDescriptor(
				this, new JDBFileConnectionPanel());
		WizardPanelDescriptor descriptor2 = new TableModeDescriptor(this,
				OutputConnectionDescriptor.IDENTIFIER,
				WizardPanelDescriptor.FINISH);

		wizard.registerWizardPanel(OutputConnectionDescriptor.IDENTIFIER,
				descriptor1);
		wizard.registerWizardPanel(TableModeDescriptor.IDENTIFIER, descriptor2);

		wizard.setKeyForReferringToDescription("help.connector.output");
		wizard.setCurrentPanel(OutputConnectionDescriptor.IDENTIFIER,
				Wizard.NEXT_BUTTON_ACTION_COMMAND);

		wizard.showModalDialog();
		*/
	}


	// save node
	@Override
	public Element saveToElement() {
		Element readNode = super.saveToElement();
		readNode.addContent("Kostas");

		return readNode;
	}

	// load node
	@Override
	public void initFromElement(Element node) {
	}


	//*************88
	

	public ImageIcon getIcon(){
		return READUtils.TEST_CONNECTOR_NODE_ICON;
	}
	
	protected void TransformRDBtoTDB() {
	}

	protected void TransformTDBtoRDB(int mode) {
	}
	
	public void Transform(){ //prepei na kataalvw ti kanei auti i sinartisi <----- ara auto eketeleitai stin run epilogi
		System.out.println("********* Irtha ***************");
		/*
		TransformTDBtoRDB(INSERT_MODE);
		
		try {
			// *
			// * Here we select the right method to call
			// * from ConnectorFunctions,  according to the selected 
			// * table (web service operation)
			
			
			//Class functionsClass = Class.forName("tuc.apon.testConnector.TestConnectorFunctions");
			Class functionsClass = Class.forName("com.apatar.READFunction");
			
			Method method = functionsClass.getMethod(getTableName(),argVals.getClass(),retVals.getClass());
			method.invoke(functionsClass.newInstance(),argVals, retVals);
			
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		}

		TransformRDBtoTDB();
		*/
	}
/*
	public void createDatabaseParam(Wizard wizard) {
		JDialog wizardDialog = wizard.getDialog();
		wizardDialog.setTitle(title + " Property");

		try {
			
			WizardPanelDescriptor descriptor1 = new RecordSourceDescriptor(
					this, DBConnectionDescriptor.IDENTIFIER,
					TableModeDescriptor.IDENTIFIER);
			wizard.registerWizardPanel(RecordSourceDescriptor.IDENTIFIER,
					descriptor1);

			WizardPanelDescriptor descriptor2 = new TableModeDescriptor(this,
					RecordSourceDescriptor.IDENTIFIER,
					WizardPanelDescriptor.FINISH);
			wizard.registerWizardPanel(TableModeDescriptor.IDENTIFIER,
					descriptor2);

			wizard.setCurrentPanel(RecordSourceDescriptor.IDENTIFIER, 
					Wizard.NEXT_BUTTON_ACTION_COMMAND);

			wizard.showModalDialog();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}*/
	
	public SchemaTable getExpectedShemaTable() {
		
		return null;
	}
	
	// build record list to write to real database
	private List<Record> BuildDestinationRecordList() throws Exception {

		return null;
	}
	
	public void createSchemaTable(AbstractApatarActions actions)
		throws Exception {

	}

	public void deleteAllRecordsInRDB() throws Exception {
	}

	public DataBaseInfo getDataBaseInfo() {
		return dbi;
	}

	public List<Record> getFieldList(AbstractApatarActions action)
	throws Exception {

		return null;
	}

	public List<RDBTable> getTableList() throws Exception {
		
		
		return null;
	}

}
